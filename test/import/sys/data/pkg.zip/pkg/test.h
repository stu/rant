
#ifndef TEST_H
#define TEST_H

void test(void);

#endif
